import numpy as np

# Hill Cipher functions

def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        t = m
        m = a % m
        a = t
        t = x0
        x0 = x1 - q * x0
        x1 = t
    if x1 < 0:
        x1 += m0
    return x1

def matrix_mod_inv(matrix, modulus):
    det = int(round(np.linalg.det(matrix)))
    det_inv = mod_inverse(det % modulus, modulus)
    if det_inv == 0:
        raise ValueError("Matrix is not invertible modulo {}".format(modulus))
    matrix_modulus_inv = det_inv * np.round(det * np.linalg.inv(matrix)).astype(int) % modulus
    return matrix_modulus_inv.astype(int)

def hill_prepare_text(text, size):
    text = text.lower().replace(' ', '')
    while len(text) % size != 0:
        text += 'x'
    return text

def hill_encrypt(plaintext, key_matrix):
    size = key_matrix.shape[0]
    plaintext = hill_prepare_text(plaintext, size)
    ciphertext = ''
    for i in range(0, len(plaintext), size):
        block = plaintext[i:i+size]
        vec = np.array([ord(c) - ord('a') for c in block])
        enc_vec = key_matrix.dot(vec) % 26
        ciphertext += ''.join(chr(num + ord('a')) for num in enc_vec)
    return ciphertext

def hill_decrypt(ciphertext, key_matrix):
    size = key_matrix.shape[0]
    decrypt_matrix = matrix_mod_inv(key_matrix, 26)
    plaintext = ''
    for i in range(0, len(ciphertext), size):
        block = ciphertext[i:i+size]
        vec = np.array([ord(c) - ord('a') for c in block])
        dec_vec = decrypt_matrix.dot(vec) % 26
        plaintext += ''.join(chr(num + ord('a')) for num in dec_vec)
    return plaintext.rstrip('x')

# Sample runs
hill_key = np.array([[3, 3], [2, 5]])
hill_samples = [
    "HELLO",
    "WORLD",
    "SECURE",
    "PYTHON",
    "CRYPTO",
    "DATA",
]

print("Hill Cipher Examples:")
print("=" * 60)
print(f"Key Matrix:\n{hill_key}\n")
for i, plaintext in enumerate(hill_samples, 1):
    encrypted = hill_encrypt(plaintext, hill_key)
    decrypted = hill_decrypt(encrypted, hill_key)
    print(f"\nRun {i}:")
    print(f"Plaintext: {plaintext}")
    print(f"Encrypted: {encrypted}")
    print(f"Decrypted: {decrypted}")
