# Columnar Transposition Cipher implementation

def columnar_transposition_encrypt(plaintext, key):
    num_cols = len(key)
    num_rows = (len(plaintext) + num_cols - 1) // num_cols
    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]

    idx = 0
    for r in range(num_rows):
        for c in range(num_cols):
            if idx < len(plaintext):
                matrix[r][c] = plaintext[idx]
            else:
                matrix[r][c] = ''
            idx += 1

    sorted_key = sorted([(char, i) for i, char in enumerate(key)])

    ciphertext = []
    for char, col in sorted_key:
        for r in range(num_rows):
            if matrix[r][col]:
                ciphertext.append(matrix[r][col])

    return ''.join(ciphertext)


def columnar_transposition_decrypt(ciphertext, key):
    num_cols = len(key)
    num_rows = (len(ciphertext) + num_cols - 1) // num_cols
    col_lens = [num_rows] * num_cols

    last_row_count = num_cols * num_rows - len(ciphertext)
    for i in range(last_row_count):
        col_lens[num_cols - 1 - i] -= 1

    sorted_key = sorted([(char, i) for i, char in enumerate(key)])

    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]
    idx = 0
    for char, col in sorted_key:
        for r in range(col_lens[col]):
            matrix[r][col] = ciphertext[idx]
            idx += 1

    plaintext = []
    for r in range(num_rows):
        for c in range(num_cols):
            if matrix[r][c]:
                plaintext.append(matrix[r][c])

    return ''.join(plaintext)


# Sample usage and test cases
if __name__ == "__main__":
    sample_col_texts = [
        "HELLOWORLD",
        "CRYPTOGRAPHY",
        "SARDARPATEL",
        "COLUMNARCIPHER",
        "DOUBLETRANSPOSITION",
        "SECUREMESSAGE"
    ]

    col_keys = ["ZEBRAS", "KEYWORD", "FACULTY", "SECURE", "PASSWORD", "COMPUTER"]

    for i in range(6):
        plaintext = sample_col_texts[i]
        key = col_keys[i]

        encrypted = columnar_transposition_encrypt(plaintext, key)
        decrypted = columnar_transposition_decrypt(encrypted, key)

        print(f"Run {i + 1}:")
        print(f"Plaintext: {plaintext}")
        print(f"Key: {key}")
        print(f"Encrypted: {encrypted}")
        print(f"Decrypted: {decrypted}")
        print(f"Decryption Successful: {plaintext == decrypted}")
        print("-" * 50)
