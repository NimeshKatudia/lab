import random
import math
from sympy import isprime, gcd, mod_inverse


class RSA:
    def __init__(self):
        self.public_key = None
        self.private_key = None
        self.n = None

    def generate_prime(self, bit_length):
        """Generate a prime number of specified bit length"""
        while True:
            # Generate random odd number of specified bit length
            num = random.getrandbits(bit_length)
            # Ensure it's odd and has correct bit length
            num |= (1 << bit_length - 1) | 1
            if isprime(num):
                return num

    def generate_keys(self, bit_length):
        """Generate RSA public and private keys"""
        print(f"\nGenerating RSA keys with {bit_length}-bit primes...")

        # Step 1: Choose two large distinct primes p and q
        p = self.generate_prime(bit_length // 2)
        q = self.generate_prime(bit_length // 2)

        # Ensure p and q are distinct
        while p == q:
            q = self.generate_prime(bit_length // 2)

        print(f"Prime p: {p}")
        print(f"Prime q: {q}")

        # Step 2: Compute n = p×q and Euler's totient φ(n) = (p–1)(q–1)
        n = p * q
        phi_n = (p - 1) * (q - 1)

        print(f"n = p × q: {n}")
        print(f"φ(n) = (p-1)(q-1): {phi_n}")

        # Step 3: Select an integer e such that 1 < e < φ(n) and gcd(e, φ(n)) = 1
        e = 65537  # Common choice for e (2^16 + 1)
        while gcd(e, phi_n) != 1:
            e += 2

        print(f"Public exponent e: {e}")

        # Step 4: Compute the modular multiplicative inverse d of e modulo φ(n)
        d = mod_inverse(e, phi_n)

        print(f"Private exponent d: {d}")

        # Step 5: Store keys
        self.public_key = (e, n)
        self.private_key = (d, n)
        self.n = n

        print(f"\nPublic Key (e, n): ({e}, {n})")
        print(f"Private Key (d, n): ({d}, {n})")

        return self.public_key, self.private_key

    def encrypt(self, plaintext, public_key=None):
        """Encrypt message using public key"""
        if public_key is None:
            public_key = self.public_key

        if public_key is None:
            print("Error: No public key available. Generate keys first.")
            return None

        e, n = public_key

        # Convert string to integer if needed
        if isinstance(plaintext, str):
            message = int.from_bytes(plaintext.encode('utf-8'), 'big')
        else:
            message = int(plaintext)

        # Check if message is within valid range
        if message >= n:
            print(f"Error: Message too large. Must be less than n = {n}")
            return None

        # Encryption: c ≡ m^e mod n
        ciphertext = pow(message, e, n)

        print(f"Plaintext (as integer): {message}")
        print(f"Ciphertext: {ciphertext}")

        return ciphertext

    def decrypt(self, ciphertext, private_key=None):
        """Decrypt message using private key"""
        if private_key is None:
            private_key = self.private_key

        if private_key is None:
            print("Error: No private key available. Generate keys first.")
            return None

        d, n = private_key

        # Decryption: m ≡ c^d mod n
        decrypted = pow(int(ciphertext), d, n)

        print(f"Ciphertext: {ciphertext}")
        print(f"Decrypted (as integer): {decrypted}")

        # Try to convert back to string
        try:
            decrypted_text = decrypted.to_bytes((decrypted.bit_length() + 7) // 8, 'big').decode('utf-8')
            print(f"Decrypted text: '{decrypted_text}'")
            return decrypted_text
        except:
            print(f"Decrypted message (integer): {decrypted}")
            return decrypted


def main():
    rsa = RSA()

    while True:
        print("\n" + "=" * 60)
        print("RSA CRYPTOSYSTEM - MENU")
        print("=" * 60)
        print("1) Generate RSA Keys")
        print("2) Encrypt Message")
        print("3) Decrypt Message")
        print("4) Quit")
        print("=" * 60)

        try:
            choice = input("Enter your choice (1-4): ").strip()

            if choice == '1':
                print("\n--- KEY GENERATION ---")
                bit_length = int(input("Enter bit length for keys (e.g., 512, 1024): "))
                if bit_length < 64:
                    print("Warning: Very small key size. Recommended minimum: 512 bits")

                rsa.generate_keys(bit_length)

            elif choice == '2':
                print("\n--- ENCRYPTION ---")
                if rsa.public_key is None:
                    print("Error: No keys generated. Please generate keys first.")
                    continue

                message = input("Enter message to encrypt: ")
                if not message:
                    print("Error: Empty message")
                    continue

                print(f"Using public key: {rsa.public_key}")
                ciphertext = rsa.encrypt(message)

            elif choice == '3':
                print("\n--- DECRYPTION ---")
                if rsa.private_key is None:
                    print("Error: No keys generated. Please generate keys first.")
                    continue

                ciphertext = input("Enter ciphertext to decrypt: ")
                if not ciphertext:
                    print("Error: Empty ciphertext")
                    continue

                try:
                    ciphertext = int(ciphertext)
                except ValueError:
                    print("Error: Ciphertext must be a number")
                    continue

                print(f"Using private key: {rsa.private_key}")
                rsa.decrypt(ciphertext)

            elif choice == '4':
                print("Goodbye!")
                break

            else:
                print("Invalid choice. Please enter 1-4.")

        except KeyboardInterrupt:
            print("\nProgram interrupted. Goodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    print("RSA Algorithm Implementation")
    print("Experiment 3 - Cryptography Lab")
    print("Bharatiya Vidya Bhavan's Sardar Patel Institute of Technology")

    # Demonstrate end-to-end run
    print("\n" + "=" * 60)
    print("DEMONSTRATION: END-TO-END RSA ENCRYPTION/DECRYPTION")
    print("=" * 60)

    demo_rsa = RSA()

    # Generate keys
    print("\n1. Generating 512-bit RSA keys...")
    demo_rsa.generate_keys(512)

    # Encrypt message
    print("\n2. Encrypting message 'Hello RSA!'...")
    demo_message = "Hello RSA!"
    demo_ciphertext = demo_rsa.encrypt(demo_message)

    # Decrypt message
    print("\n3. Decrypting the ciphertext...")
    demo_rsa.decrypt(demo_ciphertext)

    print("\n" + "=" * 60)
    print("DEMONSTRATION COMPLETE - Starting Interactive Menu")
    print("=" * 60)

    # Start interactive menu
    main()
