import hashlib
import os

# Initialize output file
output_file = "Exp05-VineetChanne-2022300013-InputOutput.txt"
with open(output_file, 'w') as out_f:
    out_f.write("=================================================================\n")
    out_f.write("CSS EXPERIMENT 5 - GENERATE AND CALCULATE HASHES AND CHECKSUM FILES\n")
    out_f.write("Student: Vineet Channe\n")
    out_f.write("Roll No: 2022300013\n")
    out_f.write("Date: September 21, 2025\n")
    out_f.write("=================================================================\n\n")

# Step 1: Create sample input file (200-300 characters)
sample_content = """This is a sample text file for demonstrating hash functions and checksum verification.
Hash functions are one-way mathematical functions that produce a fixed-length digest from any input.
They are deterministic, collision-resistant, and exhibit the avalanche effect where small changes
in input produce large changes in output. This text contains approximately 300 characters."""

# Create the input file
with open('example.txt', 'w') as f:
    f.write(sample_content)

# Write input file info to output
with open(output_file, 'a') as out_f:
    out_f.write("INPUT FILE CREATED:\n")
    out_f.write("-" * 30 + "\n")
    out_f.write(f"Filename: example.txt\n")
    out_f.write(f"Size: {len(sample_content)} characters\n")
    out_f.write("Content:\n")
    out_f.write(sample_content + "\n\n")


# Step 2: Hash Generation Function
def generate_hashes(filename):
    """Generate MD5, SHA-1, SHA-256, and SHA-512 hashes for a given file"""
    hashes = {}

    with open(filename, 'rb') as f:
        file_content = f.read()

    hashes['MD5'] = hashlib.md5(file_content).hexdigest()
    hashes['SHA-1'] = hashlib.sha1(file_content).hexdigest()
    hashes['SHA-256'] = hashlib.sha256(file_content).hexdigest()
    hashes['SHA-512'] = hashlib.sha512(file_content).hexdigest()

    return hashes


# Step 3: Create Hash Report (modified to also write to output file)
def create_hash_report(filename, hashes):
    """Create hash_report.txt containing all hash values"""
    # Create separate hash_report.txt file
    with open('hash_report.txt', 'w') as f:
        f.write("HASH REPORT\n")
        f.write("=" * 50 + "\n")
        f.write(f"File: {filename}\n")
        f.write(f"File size: {os.path.getsize(filename)} bytes\n")
        f.write("=" * 50 + "\n\n")

        for hash_type, hash_value in hashes.items():
            f.write(f"{hash_type}:\n")
            f.write(f"{hash_value}\n\n")

        f.write("=" * 50 + "\n")
        f.write("Report generated successfully\n")

    # Also append to output file
    with open(output_file, 'a') as out_f:
        out_f.write("HASH REPORT CONTENT:\n")
        out_f.write("-" * 30 + "\n")
        out_f.write("HASH REPORT\n")
        out_f.write("=" * 50 + "\n")
        out_f.write(f"File: {filename}\n")
        out_f.write(f"File size: {os.path.getsize(filename)} bytes\n")
        out_f.write("=" * 50 + "\n\n")

        for hash_type, hash_value in hashes.items():
            out_f.write(f"{hash_type}:\n")
            out_f.write(f"{hash_value}\n\n")

        out_f.write("=" * 50 + "\n")
        out_f.write("Report generated successfully\n\n")


# Step 4: Create Checksum File (modified to also write to output file)
def create_checksum_file(filename, hash_value):
    """Create example.txt.sha256 checksum file"""
    checksum_filename = f"{filename}.sha256"
    checksum_content = f"{hash_value}  {filename}\n"

    # Create separate checksum file
    with open(checksum_filename, 'w') as f:
        f.write(checksum_content)

    # Also append to output file
    with open(output_file, 'a') as out_f:
        out_f.write(f"CHECKSUM FILE CONTENT ({checksum_filename}):\n")
        out_f.write("-" * 30 + "\n")
        out_f.write(checksum_content + "\n")

    return checksum_filename


# Step 5: Verify Checksum
def verify_checksum(filename, checksum_filename):
    """Verify file integrity using checksum file"""
    # Read stored hash from checksum file
    with open(checksum_filename, 'r') as f:
        stored_hash, stored_filename = f.read().strip().split('  ')

    # Calculate current hash
    current_hash = hashlib.sha256(open(filename, 'rb').read()).hexdigest()

    # Compare hashes
    if current_hash == stored_hash:
        return "Checksum OK (Authentic)"
    else:
        return "Checksum FAILED (Tampered)"


# Step 6: Tampering Test
def tamper_file(filename):
    """Modify file to simulate tampering"""
    with open(filename, 'a') as f:
        f.write(" TAMPERED")


# Execute the experiment
print("=== CSS EXPERIMENT 5: HASH FUNCTIONS AND CHECKSUM VERIFICATION ===\n")

# Write execution start to output file
with open(output_file, 'a') as out_f:
    out_f.write("EXPERIMENT EXECUTION:\n")
    out_f.write("=" * 30 + "\n\n")

# Generate hashes
filename = 'example.txt'
file_hashes = generate_hashes(filename)

print("1. HASH GENERATION RESULTS:")
print("-" * 40)
with open(output_file, 'a') as out_f:
    out_f.write("1. HASH GENERATION RESULTS:\n")
    out_f.write("-" * 40 + "\n")

for hash_type, hash_value in file_hashes.items():
    print(f"{hash_type}: {hash_value}")
    with open(output_file, 'a') as out_f:
        out_f.write(f"{hash_type}: {hash_value}\n")

with open(output_file, 'a') as out_f:
    out_f.write("\n")

# Create hash report
create_hash_report(filename, file_hashes)
print(f"\n2. Hash report saved to: hash_report.txt")
with open(output_file, 'a') as out_f:
    out_f.write("2. Hash report saved to: hash_report.txt\n\n")

# Create checksum file
checksum_file = create_checksum_file(filename, file_hashes['SHA-256'])
print(f"3. Checksum file created: {checksum_file}")
with open(output_file, 'a') as out_f:
    out_f.write(f"3. Checksum file created: {checksum_file}\n\n")

# Verify before tampering
print(f"\n4. VERIFICATION BEFORE TAMPERING:")
result = verify_checksum(filename, checksum_file)
print(f"Result: {result}")
with open(output_file, 'a') as out_f:
    out_f.write("4. VERIFICATION BEFORE TAMPERING:\n")
    out_f.write(f"Result: {result}\n\n")

# Tamper with file
tamper_file(filename)
print(f"\n5. FILE TAMPERING: Added text to {filename}")
with open(output_file, 'a') as out_f:
    out_f.write(f"5. FILE TAMPERING: Added text to {filename}\n\n")

# Verify after tampering
print(f"\n6. VERIFICATION AFTER TAMPERING:")
result = verify_checksum(filename, checksum_file)
print(f"Result: {result}")
with open(output_file, 'a') as out_f:
    out_f.write("6. VERIFICATION AFTER TAMPERING:\n")
    out_f.write(f"Result: {result}\n\n")

print(f"\n=== EXPERIMENT COMPLETED ===")

# Write completion to output file
with open(output_file, 'a') as out_f:
    out_f.write("=== EXPERIMENT COMPLETED ===\n")
    out_f.write("All results saved in: " + output_file + "\n")
    out_f.write("=================================================================\n")

print(f"\nAll experiment data saved to: {output_file}")
