import string

# Caesar Cipher functions

def caesar_encrypt(text, shift):
    result = []
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            offset = (ord(char) - base + shift) % 26
            result.append(chr(base + offset))
        else:
            result.append(char)
    return ''.join(result)

def caesar_decrypt(cipher, shift):
    return caesar_encrypt(cipher, -shift)

# Sample runs
caesar_samples = [
    ("HELLO WORLD", 3),
    ("CRYPTOGRAPHY", 5),
    ("SARDAR PATEL", 10),
    ("ENCRYPTION", 1),
    ("DATA SECURITY", 7),
    ("PYTHON PROGRAM", 2),
]

print("Caesar Cipher Examples:")
print("=" * 60)
for i, (plaintext, key) in enumerate(caesar_samples, 1):
    encrypted = caesar_encrypt(plaintext, key)
    decrypted = caesar_decrypt(encrypted, key)
    print(f"\nRun {i}:")
    print(f"Plaintext: {plaintext}")
    print(f"Key (Shift): {key}")
    print(f"Encrypted: {encrypted}")
    print(f"Decrypted: {decrypted}")
