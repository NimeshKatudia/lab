#!/usr/bin/env python3
# Exp04-<Your-Name>-<Your-UID>-Source.py
# Diffie-Hellman key exchange demo with standardized MODP/FFDHE groups and demo safe-prime generation.
# For lab use only. Do not use the demo XOR scheme in production.

import secrets
import hashlib
import textwrap

# --------------------------
# RFC standardized parameters
# --------------------------
# RFC 3526: 2048-bit MODP Group 14, generator g = 2 (p hex consolidated)
# RFC 7919: ffdhe2048, generator g = 2 (p hex consolidated)
# See RFC 3526 §3 (MODP-2048) and RFC 7919 Appendix A.1 (ffdhe2048).

MODP_2048_HEX = """
FFFFFFFF FFFFFFFF C90FDAA2 2168C234 C4C6628B 80DC1CD1
29024E08 8A67CC74 020BBEA6 3B139B22 514A0879 8E3404DD
EF9519B3 CD3A431B 302B0A6D F25F1437 4FE1356D 6D51C245
E485B576 625E7EC6 F44C42E9 A637ED6B 0BFF5CB6 F406B7ED
EE386BFB 5A899FA5 AE9F2411 7C4B1FE6 49286651 ECE45B3D
C2007CB8 A163BF05 98DA4836 1C55D39A 69163FA8 FD24CF5F
83655D23 DCA3AD96 1C62F356 208552BB 9ED52907 7096966D
670C354E 4ABC9804 F1746C08 CA18217C 32905E46 2E36CE3B
E39E772C 180E8603 9B2783A2 EC07A28F B5C55DF0 6F4C52C9
DE2BCBF6 95581718 3995497C EA956AE5 15D22618 98FA0510
15728E5A 8AACAA68 FFFFFFFF FFFFFFFF
"""

FFDHE_2048_HEX = """
FFFFFFFF FFFFFFFF ADF85458 A2BB4A9A AFDC5620 273D3CF1 D8B9C583 CE2D3695
A9E13641 146433FB CC939DCE 249B3EF9 7D2FE363 630C75D8 F681B202 AEC4617A
D3DF1ED5 D5FD6561 2433F51F 5F066ED0 85636555 3DED1AF3 B557135E 7F57C935
984F0C70 E0E68B77 E2A689DA F3EFE872 1DF158A1 36ADE735 30ACCA4F 483A797A
BC0AB182 B324FB61 D108A94B B2C8E3FB B96ADAB7 60D7F468 1D4F42A3 DE394DF4
AE56EDE7 6372BB19 0B07A7C8 EE0A6D70 9E02FCE1 CDF7E2EC C03404CD 28342F61
9172FE9C E98583FF 8E4F1232 EEF28183 C3FE3B1B 4C6FAD73 3BB5FCBC 2EC22005
C58EF183 7D1683B2 C6F34A26 C1B2EFFA 886B4238 61285C97 FFFFFFFF FFFFFFFF
"""

def _hex_to_int(s: str) -> int:
    return int("".join(s.split()), 16)

STANDARD_GROUPS = {
    "MODP-2048 (RFC3526 group14)": {"p": _hex_to_int(MODP_2048_HEX), "g": 2},
    "FFDHE-2048 (RFC7919 ffdhe2048)": {"p": _hex_to_int(FFDHE_2048_HEX), "g": 2},
}

# --------------------------
# Primality and safe-prime generation (demo only)
# --------------------------

def _miller_rabin(n: int, k: int = 64) -> bool:
    if n < 2:
        return False
    small_primes = [2,3,5,7,11,13,17,19,23,29,31,37]
    for sp in small_primes:
        if n == sp:
            return True
        if n % sp == 0:
            return False
    # write n-1 as d*2^r
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for _ in range(k):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        witness = True
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                witness = False
                break
        if witness:
            return False
    return True

def generate_safe_prime(bits: int) -> tuple[int, int]:
    if bits < 256:
        raise ValueError("bits must be >= 256 for demo")
    while True:
        q = secrets.randbits(bits - 1)
        q |= (1 << (bits - 2))  # ensure top bit
        q |= 1                  # make odd
        if not _miller_rabin(q):
            continue
        p = 2 * q + 1
        if _miller_rabin(p):
            return p, q

def find_generator_of_order_q(p: int, q: int) -> int:
    # For safe prime p=2q+1, subgroup of order q: g = h^((p-1)/q) mod p
    while True:
        h = secrets.randbelow(p - 3) + 2  # [2, p-2]
        g = pow(h, (p - 1) // q, p)
        if g > 1:
            return g

# --------------------------
# DH operations and KDF
# --------------------------

def generate_private_key(p: int) -> int:
    return secrets.randbelow(p - 3) + 2  # in [2, p-2]

def compute_public_key(g: int, x: int, p: int) -> int:
    return pow(g, x, p)

def validate_peer_pub(Y: int, p: int, q: int | None) -> bool:
    # Range check (prevents 2-element subgroup)
    if not (1 < Y < p - 1):
        return False
    # If subgroup order q is known, ensure Y in order-q subgroup
    if q is not None:
        if pow(Y, q, p) != 1:
            return False
    else:
        # For standardized safe-prime groups, q = (p-1)//2 (safe prime)
        q_candidate = (p - 1) // 2
        if pow(Y, q_candidate, p) != 1:
            return False
    return True

def compute_shared_secret(peer_pub: int, priv: int, p: int) -> int:
    return pow(peer_pub, priv, p)

def int_to_bytes(n: int) -> bytes:
    if n == 0:
        return b"\x00"
    return n.to_bytes((n.bit_length() + 7) // 8, "big")

def kdf_sha256(shared_secret: int) -> bytes:
    return hashlib.sha256(int_to_bytes(shared_secret)).digest()

def xor_stream(data: bytes, key: bytes) -> bytes:
    # Repeat key to match data length (demo only)
    if not key:
        raise ValueError("Key must be non-empty")
    ks = (key * ((len(data) + len(key) - 1) // len(key)))[:len(data)]
    return bytes(d ^ k for d, k in zip(data, ks))

# --------------------------
# UI helpers
# --------------------------

def print_params(name: str, p: int, g: int) -> None:
    print(f"\nSelected parameters: {name}")
    print("p (hex) =")
    print(textwrap.fill(hex(p)[2:], 64))
    print(f"g = {g}")

# --------------------------
# Menu-driven CLI
# --------------------------

def main():
    p = g = q = None
    a = A = b = B = None
    shared_a = shared_b = None
    symm_key = None

    while True:
        print("\nDiffie-Hellman Key Exchange Demo")
        print("1) Select / Generate Public Parameters (p, g)")
        print("2) Generate Keys for Alice and Bob")
        print("3) Compute Shared Secret")
        print("4) Derive Symmetric Key & Demo Encrypt/Decrypt (Optional)")
        print("5) Exit")
        choice = input("Enter choice: ").strip()

        if choice == "1":
            print("\nChoose parameter source:")
            print("  a) Standard MODP-2048 (RFC3526 group14)")
            print("  b) Standard FFDHE-2048 (RFC7919 ffdhe2048)")
            print("  c) Generate demo safe-prime (512–1024 bits)")
            sub = input("Select a/b/c: ").strip().lower()
            if sub == "a":
                name = "MODP-2048 (RFC3526 group14)"
                p = STANDARD_GROUPS[name]["p"]; g = STANDARD_GROUPS[name]["g"]; q = None
                print_params(name, p, g)
            elif sub == "b":
                name = "FFDHE-2048 (RFC7919 ffdhe2048)"
                p = STANDARD_GROUPS[name]["p"]; g = STANDARD_GROUPS[name]["g"]; q = None
                print_params(name, p, g)
            elif sub == "c":
                try:
                    bits = int(input("Enter bit-length for demo (512–1024 recommended): ").strip())
                except ValueError:
                    print("Invalid bit-length"); continue
                print("Generating safe prime p=2q+1 (this may take a while)...")
                p, q = generate_safe_prime(bits)
                g = find_generator_of_order_q(p, q)
                print_params(f"Demo safe-prime ~{bits} bits", p, g)
                print("Note: Demo group is for lab demonstration only; use standardized 2048-bit groups in practice.")
            else:
                print("Invalid selection"); continue
            # reset downstream state
            a = A = b = B = shared_a = shared_b = symm_key = None

        elif choice == "2":
            if p is None or g is None:
                print("Select / generate (p, g) first."); continue
            a = generate_private_key(p)
            b = generate_private_key(p)
            A = compute_public_key(g, a, p)
            B = compute_public_key(g, b, p)
            print("\nGenerated Keys:")
            print("Alice's Private Key: <hidden>")
            print(f"Alice's Public Key A = {A}")
            print("Bob's Private Key: <hidden>")
            print(f"Bob's Public Key B = {B}")
            show = input("Show private keys? (y/n): ").strip().lower()
            if show == "y":
                print(f"Alice's Private Key a = {a}")
                print(f"Bob's Private Key b = {b}")

        elif choice == "3":
            if None in (p, g, a, A, b, B):
                print("Generate keys first."); continue
            if not validate_peer_pub(B, p, q):
                print("Error: Bob's public key failed validation (range/subgroup)."); continue
            if not validate_peer_pub(A, p, q):
                print("Error: Alice's public key failed validation (range/subgroup)."); continue
            shared_a = compute_shared_secret(B, a, p)
            shared_b = compute_shared_secret(A, b, p)
            print(f"Alice's computed shared secret K_A = {shared_a}")
            print(f"Bob's computed shared secret   K_B = {shared_b}")
            print("Shared secrets match. Key agreement successful." if shared_a == shared_b else "Mismatch! Check parameters/keys.")

        elif choice == "4":
            if shared_a is None or shared_b is None or shared_a != shared_b:
                print("Compute matching shared secret first."); continue
            symm_key = kdf_sha256(shared_a)
            print(f"Derived symmetric key (SHA-256 of shared secret): {symm_key.hex()}")
            msg = input("Enter a short message to encrypt: ")
            pt = msg.encode("utf-8")
            ct = xor_stream(pt, symm_key)
            print(f"Ciphertext (hex): {ct.hex()}")
            rt = xor_stream(ct, symm_key)
            print(f"Decrypted message: {rt.decode('utf-8', errors='strict')}")

        elif choice == "5":
            print("Exiting."); break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
