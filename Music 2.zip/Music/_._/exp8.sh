#!/bin/bash
set -e

# --- Setup Terminal Environment ---
BOLD_GREEN='\033[1;32m'
BOLD_BLUE='\033[1;34m'
NC='\033[0m' 

# --- Helper function to print prompts ---
run() {
    CURRENT_DIR=$(pwd | sed "s|^$HOME|~|")
    PROMPT="${BOLD_GREEN}${USER}@$(hostname):${BOLD_BLUE}${CURRENT_DIR}${NC}$ "
    echo -e "\n${PROMPT}$@"
    eval "$@"
}

# --- 1. Check Docker ---
if ! command -v docker &> /dev/null; then
    run "curl -fsSL https://get.docker.com -o get-docker.sh"
    run "sudo sh get-docker.sh"
    run "sudo usermod -aG docker $USER"
    echo "Docker installed. Please log out and back in if you get permission errors."
    exit 1
fi

# --- 2. Setup Container ---
#echo -e "\n--- Setting up Firewall Lab Container ---"
# Force remove old container
docker rm -f firewall-lab 2>/dev/null || true

# Run with NET_ADMIN to allow iptables
run "docker run -itd --name firewall-lab --cap-add=NET_ADMIN ubuntu:latest"

#echo -e "\n--- Installing Tools (iptables, ssh, nginx, etc.) ---"
# Update and install tools non-interactively
# Note: We don't use 'run' here because these are long internal setup commands
docker exec firewall-lab bash -c "apt-get update >/dev/null 2>&1 && \
    apt-get install -y iptables iputils-ping net-tools curl openssh-server nginx sudo nano >/dev/null 2>&1"

# Start services to test ports 80 (HTTP) and 22 (SSH)
#echo "Starting SSH and Nginx servers inside container..."
docker exec firewall-lab bash -c "service nginx start && service ssh start"

# Get Network Info
CONTAINER_IP=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' firewall-lab)
GATEWAY_IP=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.Gateway}}{{end}}' firewall-lab)

#echo -e "\n\033[1;32m=== CONTAINER READY ===\033[0m"
#echo "Container IP: $CONTAINER_IP"
#echo "Gateway IP:   $GATEWAY_IP"

# --- 3. Apply Firewall Rules Inside Container ---
#echo -e "\n--- Applying Firewall Rules (Only SSH & HTTP Allowed) ---"

# 1. Set Default Policies (Block Input/Forward, Allow Output)
run "docker exec firewall-lab iptables -P INPUT DROP"
run "docker exec firewall-lab iptables -P FORWARD DROP"
run "docker exec firewall-lab iptables -P OUTPUT ACCEPT"

# 2. Allow SSH (22) and HTTP (80)
run "docker exec firewall-lab iptables -A INPUT -p tcp --dport 22 -j ACCEPT"
run "docker exec firewall-lab iptables -A INPUT -p tcp --dport 80 -j ACCEPT"

# 3. Allow established connections (Critical for apt/curl/responses to work)
run "docker exec firewall-lab iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"

# 4. Block specific IP (Blocking the Docker Gateway IP as per lab requirement)
run "docker exec firewall-lab iptables -A INPUT -s $GATEWAY_IP -j DROP"

# --- 4. Verification ---
#echo -e "\n--- Verification: Current IPTables Rules ---"
# Using 'run' so you see the command being executed
run "docker exec firewall-lab iptables -L -v -n"

#echo -e "\n\033[1;32m=== LAB COMPLETE ===\033[0m"
#echo "The container 'firewall-lab' is running with the firewall active."
#echo "Only SSH (22) and HTTP (80) are allowed."
#echo "Traffic from $GATEWAY_IP is explicitly blocked."