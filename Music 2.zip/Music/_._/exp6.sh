#!/bin/bash
set -e

# --- Setup Terminal Environment ---
export GPG_TTY=$(tty)
BOLD_GREEN='\033[1;32m'
BOLD_BLUE='\033[1;34m'
NC='\033[0m' 

# --- Helper function to print prompts ---
run() {
    CURRENT_DIR=$(pwd | sed "s|^$HOME|~|")
    PROMPT="${BOLD_GREEN}${USER}@$(hostname):${BOLD_BLUE}${CURRENT_DIR}${NC}$ "
    echo -e "\n${PROMPT}$@"
    eval "$@"
}

# --- CLEANUP & SETUP ---
echo "--- Cleaning up previous runs ---"
gpgconf --kill gpg-agent 2>/dev/null || true
rm -rf pgp_exp

mkdir -p pgp_exp
cd pgp_exp

# Create GPG Home with correct permissions
mkdir -p gpg_home
chmod 700 gpg_home
export GNUPGHOME="$(pwd)/gpg_home"

echo "--- Setup: Preparing environment ---"

# --- PRE-SETUP: Generate Bob's Key (Background) ---
# Create a temporary home for Bob to avoid keyring conflicts
mkdir -p bob_tmp
chmod 700 bob_tmp

# Switch context to Bob
OLD_HOME="$GNUPGHOME"
export GNUPGHOME="$(pwd)/bob_tmp"

# Generate Bob's Key
cat > bob_params <<EOF
    %echo Generating Bob key
    Key-Type: RSA
    Key-Length: 2048
    Name-Real: Bob
    Name-Email: bob@example.com
    Expire-Date: 0
    Passphrase: password123
    %commit
EOF
gpg --batch --quiet --generate-key bob_params

# Export Bob's public key to the main experiment directory
gpg --armor --export bob@example.com > "$OLD_HOME/../bob_pub.asc"

# Restore Alice's context
export GNUPGHOME="$OLD_HOME"
rm -rf bob_tmp

# --- START EXPERIMENT ---
echo -e "\n--- PGP Experiment Started ---"

# --- Step 1: Generate Alice's Key ---
echo -e "\n Please enter a passphrase for Alice's new key."
read -sp "Passphrase: " PASSPHRASE
echo ""

cat > alice_params <<EOF
    %echo Generating Alice Key
    Key-Type: RSA
    Key-Length: 2048
    Name-Real: Alice
    Name-Email: alice@example.com
    Expire-Date: 0
    Passphrase: $PASSPHRASE
    %commit
EOF

run 'gpg --batch --generate-key alice_params'

# List keys
run 'gpg --list-keys'
run 'gpg --list-secret-keys'

# --- Step 2: Export Public Key ---
run 'gpg --armor --export alice@example.com > alice_pub.asc'
echo "--- Content of alice_pub.asc (First 5 lines) ---"
head -n 5 alice_pub.asc

# --- Step 3: Encrypt a file ---
run 'echo "This is a confidential report for Alice." > message.txt'
run 'echo "This is a PDF report." > report.pdf'

# --trust-model always bypasses the interactive trust check
run 'gpg --batch --yes --trust-model always --encrypt --recipient alice@example.com --armor -o message.asc message.txt'

# --- Step 4: Decrypt the file ---
run "gpg --batch --yes --pinentry-mode loopback --passphrase '$PASSPHRASE' --output decrypted.txt --decrypt message.asc"
echo "--- Content of decrypted.txt ---"
cat decrypted.txt

# --- Step 5: Create Detached Signature ---
run "gpg --batch --yes --pinentry-mode loopback --passphrase '$PASSPHRASE' --output report.sig --detach-sign report.pdf"

# --- Step 6: Verify Signature ---
run 'gpg --verify report.sig report.pdf'

# --- Step 7: Revocation Certificate ---
# FIX: Removed '--batch' here because gen-revoke refuses to run in batch mode.
# We pipe the inputs (1=Key Compromised, y=Description, y=Confirm) manually.
echo -e "\n${BOLD_GREEN}${USER}@$(hostname):${BOLD_BLUE}${CURRENT_DIR}${NC}$ gpg --output revoke.asc --gen-revoke alice@example.com"
echo -e "1\ny\ny\n" | gpg --yes --pinentry-mode loopback --passphrase "$PASSPHRASE" --command-fd 0 --output revoke.asc --gen-revoke alice@example.com

# --- Step 8: Import Bob's Key ---
run 'gpg --import bob_pub.asc'

# --- Step 9: Encrypt & Sign for Bob ---
# Trust Bob locally to avoid warnings
echo -e "5\ny\n" | gpg --command-fd 0 --batch --edit-key bob@example.com trust >/dev/null 2>&1

run "gpg --batch --yes --pinentry-mode loopback --passphrase '$PASSPHRASE' --encrypt --sign --recipient bob@example.com --armor -o message_to_bob.asc message.txt"
